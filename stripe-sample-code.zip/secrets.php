<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51MnlSNDQF2yCdOKi2Tub1vj9y0xIaO7irQLcUhkbuO4iG4OKuYSfJsdm5RCflRlXdDIgVhrHCzjFC8V6OIX5pdAC002GqPLFP7';